# Astro Drift

Минимальная космическая 2D-игра для Android на Kotlin и Android Canvas. Вертикальный экран, управление пальцем, работа без интернета. Игра начинается сразу после запуска.

Корабль следует за пальцем и автоматически стреляет вверх обычными пулями. Круглые метеориты падают сверху и постепенно появляются чаще. Каждое попадание уничтожает метеорит и добавляет одно очко. Столкновение корабля с метеоритом открывает экран Game Over с кнопкой «Играть снова».

Графика рисуется кодом: тёмный космос, корабль, круглые метеориты и светящиеся пули. Игровой цикл рассчитан на 60 FPS. При уходе приложения в фон игра приостанавливается.

## Проект

- `app/src/main/java/com/astrodrift/game/` — Android Activity и Canvas View.
- `app/src/main/java/com/astrodrift/game/engine/` — игровая логика без зависимости от Android.
- `app/src/test/` — проверки игровой логики.
- `gradlew` — запуск Gradle 8.9 из локального кэша или официального дистрибутива.
- `.github/workflows/build-apk.yml` — тесты, сборка debug APK и публикация артефактов.

Для GitHub Actions настроены Ubuntu 24.04, JDK 21, Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Android SDK Platform 35 и Build Tools 35.0.0. Java/Kotlin bytecode target — 17. Минимальная версия Android — 6.0 (API 23).

## GitHub Actions

Workflow `build-apk.yml` запускается при `push`, `pull_request` или вручную (`workflow_dispatch`). Проект должен находиться в корне репозитория: `settings.gradle.kts`, `app/` и `.github/` лежат на одном уровне.

Стандартный Gradle Wrapper неполон: `gradle-wrapper.jar` отсутствует. Поэтому Actions устанавливает Gradle 8.9 через `gradle/actions/setup-gradle@v4` и выполняет команды напрямую:

```sh
gradle testDebugUnitTest --no-daemon --console=plain
gradle assembleDebug --no-daemon --console=plain
```

После успешных тестов и сборки workflow проверяет, что APK существует и не пуст, затем публикует `app-debug.apk` через `actions/upload-artifact@v4` в артефакте `astro-drift-debug-apk`. Отчёты JUnit публикуются отдельно в `astro-drift-unit-test-reports`, включая случай ошибки тестов. Срок хранения артефактов — 14 дней.

Workflow подготовлен и проверен статически. GitHub Actions в этой сессии не запускался; успешная сборка и готовый APK не заявляются.

## Сборка и проверки

Для сборки нужны JDK 17 (также совместим JDK 21), Android SDK Platform 35 и Build Tools 35.0.0, а также принятые лицензии Android SDK. SDK задаётся через `ANDROID_HOME` либо `sdk.dir` в локальном `local.properties`.

В поставке используется исходный bootstrap-скрипт `gradlew`: бинарный `gradle-wrapper.jar` не включён, так как загрузка инструментов в текущей среде недоступна. Скрипт использует установленный Gradle 8.9 или скачивает официальный дистрибутив по HTTPS, проверяет SHA-256 и кэширует его. Для первого запуска требуются `curl`, `unzip`, `sha256sum` и доступ к репозиториям зависимостей. Затем стандартный wrapper можно сгенерировать командой `./gradlew wrapper`.

Сборка APK:

```sh
./gradlew assembleDebug
```

Проверки и сборка:

```sh
./gradlew --no-daemon testDebugUnitTest lintDebug assembleDebug
```

Debug APK создаётся в `app/build/outputs/apk/debug/app-debug.apk`.

Предыдущая попытка сборки в текущей среде не завершилась: Java 21 и модуль Java-компилятора доступны, но Gradle и Android SDK отсутствуют. Загрузка официального Gradle завершилась ошибкой `curl: (7) Failed to connect to proxy port 8080`. По текущему указанию скачивание инструментов и локальная сборка больше не выполняются. APK не создан; запуск игры, тестов и фактические 60 FPS не подтверждены. Подготовлены 16 тестов игровой логики.

В проекте нет других видов оружия, улучшений, боссов, магазина, лаборатории, прокачки, сложных меню или звуков.
