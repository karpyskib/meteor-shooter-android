package com.astrodrift.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import android.view.accessibility.AccessibilityNodeInfo
import com.astrodrift.game.engine.GameEngine
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** A single native Canvas view. Simulation and drawing both run on the UI thread. */
class GameView(context: Context) : View(context), Choreographer.FrameCallback {
    private val game = GameEngine()
    private val choreographer = Choreographer.getInstance()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val backgroundPaint = Paint()
    private val nebulaPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bulletGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(
            0f, 0f, 12f,
            intArrayOf(0xA031DCFF.toInt(), 0x0031DCFF),
            null, Shader.TileMode.CLAMP
        )
    }
    private val shipGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(
            0f, 0f, 30f,
            intArrayOf(0x3031DCFF, 0x0031DCFF),
            null, Shader.TileMode.CLAMP
        )
    }
    private val path = Path()
    private val cardRect = RectF()
    private val restartRect = RectF()
    private val boldTypeface = Typeface.create("sans-serif", Typeface.BOLD)
    private val regularTypeface = Typeface.create("sans-serif", Typeface.NORMAL)
    private val monoTypeface = Typeface.create("monospace", Typeface.NORMAL)
    private val stars = Array(76) { index ->
        val random = Random(index * 439 + 17)
        Star(random.nextFloat(), random.nextFloat(), .45f + random.nextFloat() * .8f,
            40 + random.nextInt(115), 3f + random.nextFloat() * 14f)
    }

    private var worldScale = 1f
    private var worldHeight = 640f
    private var hostResumed = false
    private var frameScheduled = false
    private var previousFrameNanos = 0L
    private var accumulator = 0.0
    private var activePointerId = MotionEvent.INVALID_POINTER_ID
    private var restartPressed = false
    private var displayedScore = -1
    private var scoreText = "000"
    private var wasGameOver = false

    init {
        isClickable = true
        isFocusable = true
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
        contentDescription = "Astro Drift. Ведите корабль пальцем и избегайте метеоритов."
        setBackgroundColor(BACKGROUND)
    }

    fun resumeGame() {
        hostResumed = true
        resetClock()
        scheduleFrame()
    }

    fun pauseGame() {
        hostResumed = false
        cancelTouch(stopFollowing = true)
        stopFrames()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        scheduleFrame()
    }

    override fun onDetachedFromWindow() {
        stopFrames()
        cancelTouch(stopFollowing = true)
        super.onDetachedFromWindow()
    }

    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (hasWindowFocus) {
            resetClock()
            scheduleFrame()
        } else {
            cancelTouch(stopFollowing = true)
            stopFrames()
        }
    }

    private fun canAnimate(): Boolean =
        hostResumed && isAttachedToWindow && hasWindowFocus() &&
            width > 0 && height > 0 && !game.isGameOver

    private fun scheduleFrame() {
        if (!frameScheduled && canAnimate()) {
            frameScheduled = true
            choreographer.postFrameCallback(this)
        }
    }

    private fun stopFrames() {
        choreographer.removeFrameCallback(this)
        frameScheduled = false
        resetClock()
    }

    private fun resetClock() {
        previousFrameNanos = 0L
        accumulator = 0.0
    }

    override fun doFrame(frameTimeNanos: Long) {
        frameScheduled = false
        if (!canAnimate()) return
        var needsDraw = previousFrameNanos == 0L
        if (previousFrameNanos != 0L) {
            // A stalled frame cannot advance the simulation by more than six ticks.
            accumulator += min((frameTimeNanos - previousFrameNanos) / 1_000_000_000.0, .1)
            while (accumulator >= FIXED_STEP && !game.isGameOver) {
                game.update(FIXED_STEP.toFloat())
                accumulator -= FIXED_STEP
                needsDraw = true
            }
        }
        previousFrameNanos = frameTimeNanos
        if (game.isGameOver && !wasGameOver) {
            wasGameOver = true
            restartPressed = false
            contentDescription = "Game Over. Сбито метеоритов: ${game.score}. Играть снова."
            announceForAccessibility(contentDescription)
        }
        if (needsDraw) invalidate()
        scheduleFrame()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return
        worldScale = w / WORLD_WIDTH
        worldHeight = h / worldScale
        game.resize(WORLD_WIDTH, worldHeight)
        backgroundPaint.shader = LinearGradient(
            0f, 0f, 0f, worldHeight,
            intArrayOf(0xFF0B172C.toInt(), BACKGROUND, 0xFF080D1B.toInt()),
            floatArrayOf(0f, .62f, 1f), Shader.TileMode.CLAMP
        )
        nebulaPaint.shader = RadialGradient(
            300f, worldHeight * .35f, 240f,
            intArrayOf(0x152A6F95, 0x002A6F95), null, Shader.TileMode.CLAMP
        )
        cardRect.set(27f, worldHeight * .5f - 148f, 333f, worldHeight * .5f + 148f)
        restartRect.set(49f, cardRect.top + 217f, 311f, cardRect.top + 268f)
        scheduleFrame()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.save()
        canvas.scale(worldScale, worldScale)
        drawSpace(canvas)
        drawBullets(canvas)
        drawMeteors(canvas)
        drawShip(canvas)
        drawHud(canvas)
        if (game.isGameOver) drawGameOver(canvas)
        canvas.restore()
    }

    private fun drawSpace(canvas: Canvas) {
        canvas.drawRect(0f, 0f, WORLD_WIDTH, worldHeight, backgroundPaint)
        canvas.drawRect(0f, 0f, WORLD_WIDTH, worldHeight, nebulaPaint)
        paint.style = Paint.Style.FILL
        for (star in stars) {
            paint.color = 0xFFD8E9FF.toInt()
            paint.alpha = star.alpha
            val y = (star.y * worldHeight + game.elapsedTime * star.speed) % worldHeight
            canvas.drawCircle(star.x * WORLD_WIDTH, y, star.radius, paint)
        }
        paint.alpha = 255
    }

    private fun drawBullets(canvas: Canvas) {
        for (bullet in game.bullets) {
            canvas.save()
            canvas.translate(bullet.x, bullet.y)
            canvas.drawCircle(0f, 0f, 12f, bulletGlowPaint)
            paint.color = CYAN
            canvas.drawCircle(0f, 0f, bullet.radius, paint)
            paint.color = 0xFFE8FDFF.toInt()
            canvas.drawCircle(0f, -.5f, bullet.radius * .5f, paint)
            canvas.restore()
        }
    }

    private fun drawMeteors(canvas: Canvas) {
        for (meteor in game.meteors) {
            canvas.save()
            canvas.translate(meteor.x, meteor.y)
            canvas.rotate(meteor.rotation)
            val radius = meteor.radius
            paint.color = 0xFF687184.toInt()
            canvas.drawCircle(0f, 0f, radius, paint)
            paint.color = 0xFF7B8497.toInt()
            canvas.drawCircle(-radius * .14f, -radius * .14f, radius * .8f, paint)
            paint.color = 0xFF687184.toInt()
            canvas.drawCircle(radius * .12f, radius * .12f, radius * .82f, paint)
            // The seed varies the craters without allocating random generators per frame.
            val variation = (meteor.seed and 7) * .025f
            crater(canvas, -radius * .32f, -radius * .3f, radius * (.21f + variation))
            crater(canvas, radius * .35f, radius * .16f, radius * .22f)
            crater(canvas, -radius * .17f, radius * .48f, radius * .12f)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.1f
            paint.color = 0xFF9BA6BA.toInt()
            paint.alpha = 100
            canvas.drawCircle(0f, 0f, radius - .6f, paint)
            paint.alpha = 255
            paint.style = Paint.Style.FILL
            canvas.restore()
        }
    }

    private fun crater(canvas: Canvas, x: Float, y: Float, radius: Float) {
        paint.color = 0xFF8D97A9.toInt()
        canvas.drawCircle(x, y + 1f, radius, paint)
        paint.color = 0xFF4E586D.toInt()
        canvas.drawCircle(x, y - .5f, radius, paint)
        paint.color = 0xFF5B657A.toInt()
        canvas.drawCircle(x + radius * .13f, y + radius * .2f, radius * .68f, paint)
    }

    private fun drawShip(canvas: Canvas) {
        canvas.save()
        canvas.translate(game.shipX, game.shipY)
        canvas.drawCircle(0f, 2f, 30f, shipGlowPaint)
        val flameLength = if (game.isGameOver) 6f else 7f + sin(game.elapsedTime * 28f) * 2f
        path.reset()
        path.moveTo(-4f, 8f)
        path.lineTo(0f, 8f + flameLength)
        path.lineTo(4f, 8f)
        path.close()
        paint.color = CYAN
        canvas.drawPath(path, paint)
        path.reset()
        path.moveTo(0f, -15f)
        path.lineTo(14f, 11f)
        path.lineTo(5f, 8f)
        path.lineTo(-5f, 8f)
        path.lineTo(-14f, 11f)
        path.close()
        paint.color = 0xFFD4E7F4.toInt()
        canvas.drawPath(path, paint)
        path.reset()
        path.moveTo(0f, -15f)
        path.lineTo(0f, 8f)
        path.lineTo(5f, 8f)
        path.lineTo(14f, 11f)
        path.close()
        paint.color = 0xFF849EBA.toInt()
        canvas.drawPath(path, paint)
        path.reset()
        path.moveTo(0f, -8f)
        path.lineTo(4f, 3f)
        path.lineTo(-4f, 3f)
        path.close()
        paint.color = CYAN
        canvas.drawPath(path, paint)
        paint.color = 0xFFECFAFF.toInt()
        canvas.drawCircle(0f, -2f, 1.2f, paint)
        canvas.restore()
    }

    private fun drawHud(canvas: Canvas) {
        paint.color = CYAN
        canvas.drawRoundRect(22f, 25f, 25f, 42f, 1.5f, 1.5f, paint)
        text(canvas, "ASTRO DRIFT", 34f, 38f, 12f, 0xFFE3EBF8.toInt(), boldTypeface)
        text(canvas, "СЧЁТ", 337f, 22f, 8f, MUTED, monoTypeface, Paint.Align.RIGHT)
        if (displayedScore != game.score) {
            displayedScore = game.score
            scoreText = game.score.toString().padStart(3, '0')
        }
        text(canvas, scoreText, 337f, 44f, 22f, 0xFFE7F5FF.toInt(), monoTypeface, Paint.Align.RIGHT)
        paint.color = 0xFF26334C.toInt()
        paint.strokeWidth = .7f
        canvas.drawLine(22f, 59f, 338f, 59f, paint)
        if (game.elapsedTime < 5.5f && !game.isGameOver) {
            val alpha = (min(1f, (5.5f - game.elapsedTime) / 1.5f) * 190).toInt()
            text(canvas, "Ведите корабль пальцем", 180f, worldHeight - 28f,
                12f, Color.argb(alpha, 164, 185, 211), regularTypeface, Paint.Align.CENTER)
        }
    }

    private fun drawGameOver(canvas: Canvas) {
        paint.color = 0xCC030712.toInt()
        canvas.drawRect(0f, 0f, WORLD_WIDTH, worldHeight, paint)
        paint.color = 0xFF101B30.toInt()
        canvas.drawRoundRect(cardRect, 20f, 20f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = 0xFF30415D.toInt()
        canvas.drawRoundRect(cardRect, 20f, 20f, paint)
        paint.style = Paint.Style.FILL
        paint.color = CYAN
        canvas.drawRoundRect(165f, cardRect.top + 25f, 195f, cardRect.top + 28f, 2f, 2f, paint)
        text(canvas, "GAME OVER", 180f, cardRect.top + 72f, 29f,
            0xFFF0F6FF.toInt(), boldTypeface, Paint.Align.CENTER)
        text(canvas, scoreText, 180f, cardRect.top + 149f, 48f,
            CYAN, monoTypeface, Paint.Align.CENTER)
        text(canvas, "Сбито метеоритов", 180f, cardRect.top + 176f, 13f,
            MUTED, regularTypeface, Paint.Align.CENTER)
        paint.color = if (restartPressed) 0xFF84EAFF.toInt() else CYAN
        canvas.drawRoundRect(restartRect, 12f, 12f, paint)
        text(canvas, "Играть снова", 180f, restartRect.centerY() + 5f, 16f,
            0xFF071525.toInt(), boldTypeface, Paint.Align.CENTER)
    }

    private fun text(
        canvas: Canvas, value: String, x: Float, y: Float, size: Float,
        color: Int, typeface: Typeface, alignment: Paint.Align = Paint.Align.LEFT
    ) {
        paint.color = color
        paint.typeface = typeface
        paint.textSize = size
        paint.textAlign = alignment
        paint.style = Paint.Style.FILL
        canvas.drawText(value, x, y, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!hostResumed) return false
        if (game.isGameOver) return handleGameOverTouch(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activePointerId = event.getPointerId(0)
                parent?.requestDisallowInterceptTouchEvent(true)
                followFinger(event, 0)
            }
            MotionEvent.ACTION_MOVE -> {
                val index = event.findPointerIndex(activePointerId)
                if (index >= 0) followFinger(event, index)
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (event.getPointerId(event.actionIndex) == activePointerId) {
                    val replacement = if (event.actionIndex == 0) 1 else 0
                    activePointerId = event.getPointerId(replacement)
                    followFinger(event, replacement)
                }
            }
            MotionEvent.ACTION_UP -> {
                cancelTouch()
                super.performClick()
            }
            MotionEvent.ACTION_CANCEL -> cancelTouch(stopFollowing = true)
        }
        return true
    }

    private fun followFinger(event: MotionEvent, index: Int) {
        game.moveShip(event.getX(index) / worldScale, event.getY(index) / worldScale)
    }

    private fun handleGameOverTouch(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activePointerId = event.getPointerId(0)
                restartPressed = restartRect.contains(event.x / worldScale, event.y / worldScale)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val index = event.findPointerIndex(activePointerId)
                if (index >= 0 && restartPressed) {
                    restartPressed = restartRect.contains(event.getX(index) / worldScale, event.getY(index) / worldScale)
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                val clicked = restartPressed && restartRect.contains(event.x / worldScale, event.y / worldScale)
                cancelTouch()
                if (clicked) performClick()
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (event.getPointerId(event.actionIndex) == activePointerId) cancelTouch()
            }
            MotionEvent.ACTION_CANCEL -> cancelTouch()
        }
        return true
    }

    private fun cancelTouch(stopFollowing: Boolean = false) {
        if (stopFollowing) game.moveShip(game.shipX, game.shipY)
        activePointerId = MotionEvent.INVALID_POINTER_ID
        restartPressed = false
        parent?.requestDisallowInterceptTouchEvent(false)
        invalidate()
    }

    override fun performClick(): Boolean {
        super.performClick()
        if (hostResumed && game.isGameOver) {
            game.reset()
            wasGameOver = false
            displayedScore = -1
            contentDescription = "Astro Drift. Ведите корабль пальцем и избегайте метеоритов."
            resetClock()
            invalidate()
            scheduleFrame()
        }
        return true
    }

    override fun onInitializeAccessibilityNodeInfo(info: AccessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(info)
        if (game.isGameOver) {
            info.className = "android.widget.Button"
            info.text = "Играть снова"
        }
    }

    private data class Star(val x: Float, val y: Float, val radius: Float, val alpha: Int, val speed: Float)

    companion object {
        private const val WORLD_WIDTH = 360f
        private const val FIXED_STEP = 1.0 / 60.0
        private const val BACKGROUND = 0xFF060D1C.toInt()
        private const val CYAN = 0xFF40DFFF.toInt()
        private const val MUTED = 0xFF94A7C1.toInt()
    }
}
