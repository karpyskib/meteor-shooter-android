package com.astrodrift.game.engine

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

/** Pure game simulation. All positions and speeds use logical Canvas units. */
class GameEngine(private val random: Random = Random.Default) {
    var width = 360f
        private set
    var height = 640f
        private set
    val shipRadius = 14f
    var shipX = width / 2f
        private set
    var shipY = height * 0.82f
        private set
    var score = 0
        private set
    var isGameOver = false
        private set
    var elapsedTime = 0f
        private set

    val spawnInterval: Float
        get() = (1.1f - elapsedTime * 0.008f).coerceAtLeast(0.34f)

    internal val activeBullets = ArrayList<Bullet>(24)
    internal val activeMeteors = ArrayList<Meteor>(24)
    val bullets: List<Bullet> get() = activeBullets
    val meteors: List<Meteor> get() = activeMeteors

    private var targetX = shipX
    private var targetY = shipY
    private var shotCountdown = 0f
    private var meteorCountdown = 1.1f

    fun resize(width: Float, height: Float) {
        if (!width.isFinite() || !height.isFinite() || width < 80f || height < 80f) return
        val scaleX = width / this.width
        val scaleY = height / this.height
        this.width = width
        this.height = height
        shipX = clampX(shipX * scaleX)
        shipY = clampY(shipY * scaleY)
        targetX = clampX(targetX * scaleX)
        targetY = clampY(targetY * scaleY)
        activeBullets.forEach { it.x *= scaleX; it.y *= scaleY }
        activeMeteors.forEach { it.x *= scaleX; it.y *= scaleY }
    }

    fun reset() {
        activeBullets.clear()
        activeMeteors.clear()
        shipX = width / 2f
        shipY = height * 0.82f
        targetX = shipX
        targetY = shipY
        score = 0
        elapsedTime = 0f
        isGameOver = false
        shotCountdown = 0f
        meteorCountdown = 1.1f
    }

    /** A bounded speed follows the finger without teleporting through obstacles. */
    fun moveShip(x: Float, y: Float) {
        if (isGameOver || !x.isFinite() || !y.isFinite()) return
        targetX = clampX(x)
        targetY = clampY(y)
    }

    /** Substeps also keep collision detection reliable after an unusually slow frame. */
    fun update(dt: Float) {
        if (isGameOver || !dt.isFinite() || dt <= 0f) return
        var remaining = min(dt, 0.25f)
        while (remaining > 0f && !isGameOver) {
            val stepDuration = min(remaining, 1f / 120f)
            step(stepDuration)
            remaining -= stepDuration
        }
    }

    private fun step(dt: Float) {
        val previousShipX = shipX
        val previousShipY = shipY
        val dx = targetX - shipX
        val dy = targetY - shipY
        val distance = sqrt(dx * dx + dy * dy)
        if (distance > 0f) {
            val fraction = min(1f, SHIP_SPEED * dt / distance)
            shipX += dx * fraction
            shipY += dy * fraction
        }
        elapsedTime += dt

        shotCountdown -= dt
        while (shotCountdown <= 0f) {
            activeBullets.add(Bullet(shipX, shipY - 23f))
            shotCountdown += SHOT_INTERVAL
        }
        meteorCountdown -= dt
        while (meteorCountdown <= 0f) {
            spawnMeteor()
            meteorCountdown += spawnInterval
        }

        activeBullets.forEach {
            it.previousX = it.x
            it.previousY = it.y
            it.y -= BULLET_SPEED * dt
        }
        activeMeteors.forEach {
            it.previousX = it.x
            it.previousY = it.y
            it.y += it.speed * dt
            it.rotation = (it.rotation + it.angularSpeed * dt) % 360f
        }

        resolveCollisions(previousShipX, previousShipY)
        activeBullets.removeAll { it.y + it.radius < 0f }
        activeMeteors.removeAll { it.y - it.radius > height }
    }

    private fun resolveCollisions(previousShipX: Float, previousShipY: Float) {
        // Process contacts in time order: a later bullet cannot undo a ship impact.
        while (true) {
            var firstHit = Float.POSITIVE_INFINITY
            var shipWasHit = false
            var hitBulletIndex = -1
            var hitMeteorIndex = -1
            for (meteor in activeMeteors) {
                val hit = collisionTime(
                    previousShipX - meteor.previousX,
                    previousShipY - meteor.previousY,
                    shipX - meteor.x,
                    shipY - meteor.y,
                    shipRadius + meteor.radius,
                )
                if (hit != null && hit < firstHit) {
                    firstHit = hit
                    shipWasHit = true
                }
            }
            for (bulletIndex in activeBullets.indices) {
                val bullet = activeBullets[bulletIndex]
                for (meteorIndex in activeMeteors.indices) {
                    val meteor = activeMeteors[meteorIndex]
                    val hit = collisionTime(
                        bullet.previousX - meteor.previousX,
                        bullet.previousY - meteor.previousY,
                        bullet.x - meteor.x,
                        bullet.y - meteor.y,
                        bullet.radius + meteor.radius,
                    )
                    if (hit != null && hit < firstHit) {
                        firstHit = hit
                        shipWasHit = false
                        hitBulletIndex = bulletIndex
                        hitMeteorIndex = meteorIndex
                    }
                }
            }
            if (shipWasHit) {
                isGameOver = true
                return
            }
            if (hitBulletIndex < 0) return
            activeBullets.removeAt(hitBulletIndex)
            activeMeteors.removeAt(hitMeteorIndex)
            score++
        }
    }

    private fun spawnMeteor() {
        val radius = random.nextFloat() * 12f + 22f
        val margin = radius + 4f
        activeMeteors.add(
            Meteor(
                x = margin + random.nextFloat() * max(0f, width - margin * 2f),
                y = -radius - 4f,
                radius = radius,
                speed = 100f + random.nextFloat() * 45f,
                rotation = random.nextFloat() * 360f,
                angularSpeed = random.nextFloat() * 24f - 12f,
                seed = random.nextInt(),
            ),
        )
    }

    private fun clampX(x: Float) = x.coerceIn(shipRadius + 5f, width - shipRadius - 5f)
    private fun clampY(y: Float) = y.coerceIn(shipRadius + 10f, height - shipRadius - 10f)

    companion object {
        const val SHOT_INTERVAL = 0.22f
        const val BULLET_SPEED = 620f
        const val SHIP_SPEED = 720f

        /** Intersection of a relative line segment with a circle, in [0, 1]. */
        internal fun collisionTime(
            startX: Float, startY: Float, endX: Float, endY: Float, radius: Float,
        ): Float? {
            val c = startX * startX + startY * startY - radius * radius
            if (c <= 0f) return 0f
            val dx = endX - startX
            val dy = endY - startY
            val a = dx * dx + dy * dy
            if (a < 0.000001f) return null
            val b = 2f * (startX * dx + startY * dy)
            val discriminant = b * b - 4f * a * c
            if (discriminant < 0f) return null
            val hit = (-b - sqrt(discriminant)) / (2f * a)
            return if (hit in 0f..1f) hit else null
        }
    }
}

class Bullet internal constructor(x: Float, y: Float) {
    var x = x
        internal set
    var y = y
        internal set
    val radius = 3f
    internal var previousX = x
    internal var previousY = y
}

class Meteor internal constructor(
    x: Float,
    y: Float,
    val radius: Float,
    internal val speed: Float,
    rotation: Float = 0f,
    internal val angularSpeed: Float = 0f,
    val seed: Int = 0,
) {
    var x = x
        internal set
    var y = y
        internal set
    var rotation = rotation
        internal set
    internal var previousX = x
    internal var previousY = y
}
