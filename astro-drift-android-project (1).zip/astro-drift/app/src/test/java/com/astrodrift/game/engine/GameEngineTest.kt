package com.astrodrift.game.engine

import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GameEngineTest {
    private fun engine() = GameEngine(Random(41))

    @Test fun playerStartsInsideViewportWithTimeToReact() {
        val game = engine()
        assertEquals(180f, game.shipX, 0.001f)
        assertTrue(game.shipY < game.height - game.shipRadius)
        repeat(60) { game.update(1f / 60f) }
        assertTrue(game.meteors.isEmpty())
        assertFalse(game.isGameOver)
    }

    @Test fun shipFollowsFingerAndStaysCompletelyOnScreen() {
        val game = engine()
        game.moveShip(-1000f, 10000f)
        repeat(4) { game.update(0.25f); game.activeMeteors.clear() }
        assertTrue(game.shipX >= game.shipRadius)
        assertTrue(game.shipY <= game.height - game.shipRadius)
        assertTrue(game.shipX < 30f)
        game.moveShip(10000f, -10000f)
        repeat(4) { game.update(0.25f); game.activeMeteors.clear() }
        assertTrue(game.shipX <= game.width - game.shipRadius)
        assertTrue(game.shipY >= game.shipRadius)
        assertTrue(game.shipY < 40f)
    }

    @Test fun automaticFireUsesFixedIntervalAndUpwardVelocity() {
        val game = engine()
        game.update(0.01f)
        assertEquals(1, game.bullets.size)
        val firstY = game.bullets.first().y
        game.update(0.19f)
        assertEquals(1, game.bullets.size)
        assertEquals(firstY - GameEngine.BULLET_SPEED * 0.19f, game.bullets.first().y, 0.01f)
        game.update(0.04f)
        assertEquals(2, game.bullets.size)
    }

    @Test fun meteorSpawnsAboveScreenThenFallsDownward() {
        val game = engine()
        repeat(68) { game.update(1f / 60f) }
        assertEquals(1, game.meteors.size)
        val meteor = game.meteors.single()
        assertTrue(meteor.x - meteor.radius >= 0f)
        assertTrue(meteor.x + meteor.radius <= game.width)
        assertTrue(meteor.y < 0f)
        val previousY = meteor.y
        game.update(0.05f)
        assertTrue(meteor.y > previousY)
    }

    @Test fun bulletHitRemovesMeteorAndIncrementsScoreExactlyOnce() {
        val game = engine()
        game.activeBullets.add(Bullet(100f, 220f))
        game.activeMeteors.add(Meteor(100f, 180f, 24f, 100f))
        game.update(0.05f)
        assertEquals(1, game.score)
        assertTrue(game.meteors.isEmpty())
        game.update(0.05f)
        assertEquals(1, game.score)
    }

    @Test fun oneBulletOnlyDestroysTheFirstMeteorAlongItsPath() {
        val game = engine()
        val farther = Meteor(100f, 100f, 22f, 0f)
        val nearer = Meteor(100f, 140f, 22f, 0f)
        game.activeMeteors.addAll(listOf(farther, nearer))
        game.activeBullets.add(Bullet(100f, 200f))
        game.update(0.1f)
        assertEquals(1, game.score)
        assertEquals(listOf(farther), game.meteors)
    }

    @Test fun sweptBulletCollisionCatchesMeteorThatCrossesAnEntireFrame() {
        val game = engine()
        game.activeBullets.add(Bullet(100f, 300f))
        game.activeMeteors.add(Meteor(100f, 0f, 22f, 100000f))
        game.update(1f / 120f)
        assertEquals(1, game.score)
        assertTrue(game.meteors.isEmpty())
    }

    @Test fun sweptShipCollisionCatchesFastMeteorBetweenFrameEndpoints() {
        val game = engine()
        // Off the gun's line, but inside the ship's collision radius.
        game.activeMeteors.add(Meteor(game.shipX + 30f, 0f, 22f, 100000f))
        game.update(1f / 120f)
        assertTrue(game.isGameOver)
    }

    @Test fun movingShipCannotTeleportThroughMeteor() {
        val game = engine()
        game.activeMeteors.add(Meteor(260f, game.shipY, 24f, 0f))
        game.moveShip(350f, game.shipY)
        game.update(0.25f)
        assertTrue(game.isGameOver)
        assertTrue(game.shipX < 260f)
    }

    @Test fun bulletCannotUndoAnEarlierShipImpactWithinSameStep() {
        val game = engine()
        val x = game.shipX + 30f
        game.activeMeteors.add(Meteor(x, game.shipY - 30f, 22f, 2400f))
        game.activeBullets.add(Bullet(x, game.shipY + 20f))
        game.update(1f / 120f)
        assertTrue(game.isGameOver)
        assertEquals(0, game.score)
        assertEquals(1, game.meteors.size)
    }

    @Test fun earlierBulletHitProtectsShipFromLaterImpactWithinSameStep() {
        val game = engine()
        val x = game.shipX + 30f
        game.activeMeteors.add(Meteor(x, game.shipY - 30f, 22f, 2400f))
        game.activeBullets.add(Bullet(x, game.shipY - 3f))
        game.update(1f / 120f)
        assertFalse(game.isGameOver)
        assertEquals(1, game.score)
        assertTrue(game.meteors.isEmpty())
    }

    @Test fun gameOverFreezesSimulationAndRestartRestoresInitialGame() {
        val game = engine()
        game.activeMeteors.add(Meteor(game.shipX + 30f, game.shipY, 22f, 0f))
        game.update(0.01f)
        assertTrue(game.isGameOver)
        val time = game.elapsedTime
        val x = game.shipX
        val y = game.meteors.first().y
        game.moveShip(20f, 20f)
        game.update(0.2f)
        assertEquals(time, game.elapsedTime, 0f)
        assertEquals(x, game.shipX, 0f)
        assertEquals(y, game.meteors.first().y, 0f)
        game.reset()
        assertFalse(game.isGameOver)
        assertEquals(0, game.score)
        assertEquals(0f, game.elapsedTime, 0f)
        assertTrue(game.meteors.isEmpty())
        assertTrue(game.bullets.isEmpty())
        assertEquals(game.width / 2f, game.shipX, 0.001f)
        game.update(0.01f)
        assertEquals(1, game.bullets.size)
    }

    @Test fun difficultyIncreasesButSpawnRateHasSafeLowerBound() {
        val game = engine()
        val initial = game.spawnInterval
        repeat(80) {
            game.update(0.25f)
            game.activeMeteors.clear()
        }
        assertTrue(game.spawnInterval < initial)
        repeat(400) {
            game.update(0.25f)
            game.activeMeteors.clear()
        }
        assertEquals(0.34f, game.spawnInterval, 0.0001f)
        assertTrue(game.bullets.size < 20)
        game.reset()
        assertEquals(initial, game.spawnInterval, 0.0001f)
    }

    @Test fun missedEntitiesAreRemovedWithoutGivingPoints() {
        val game = engine()
        game.activeBullets.add(Bullet(100f, -30f))
        game.activeMeteors.add(Meteor(100f, game.height + 100f, 24f, 100f))
        game.update(0.01f)
        assertTrue(game.meteors.isEmpty())
        assertEquals(1, game.bullets.size) // Only the automatic shot remains.
        assertEquals(0, game.score)
    }

    @Test fun invalidInputCannotCorruptSimulation() {
        val game = engine()
        val originalX = game.shipX
        game.moveShip(Float.NaN, Float.POSITIVE_INFINITY)
        game.resize(Float.NaN, -1f)
        game.update(Float.POSITIVE_INFINITY)
        game.update(-1f)
        assertEquals(originalX, game.shipX, 0f)
        assertEquals(0f, game.elapsedTime, 0f)
        assertEquals(360f, game.width, 0f)
        game.resize(300f, 500f)
        assertTrue(game.shipX in game.shipRadius..(game.width - game.shipRadius))
        assertTrue(game.shipY in game.shipRadius..(game.height - game.shipRadius))
    }

    @Test fun collisionSweepIncludesTangencyAndRejectsNearMiss() {
        assertNotNull(GameEngine.collisionTime(-100f, 0f, 100f, 0f, 10f))
        assertNotNull(GameEngine.collisionTime(-100f, 10f, 100f, 10f, 10f))
        assertNull(GameEngine.collisionTime(-100f, 11f, 100f, 11f, 10f))
        assertNull(GameEngine.collisionTime(20f, 20f, 20f, 20f, 10f))
    }
}
