@echo off
setlocal
if exist "%~dp0gradle\wrapper\gradle-wrapper.jar" goto wrapper
where gradle >nul 2>nul
if errorlevel 1 (
    echo Gradle 8.9 is required. Use Android Studio or install Gradle 8.9 and run gradle wrapper.
    exit /b 1
)
call gradle -p "%~dp0" %*
exit /b %ERRORLEVEL%

:wrapper
java -classpath "%~dp0gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
exit /b %ERRORLEVEL%
